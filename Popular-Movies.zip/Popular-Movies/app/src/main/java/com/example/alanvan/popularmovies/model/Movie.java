package com.example.alanvan.popularmovies.model;

public class Movie {

}
